@include('front_end.commons.header1')
            @yield('content')
@include('front_end.commons.footer')