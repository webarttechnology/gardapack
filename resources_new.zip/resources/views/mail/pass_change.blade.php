<p>Your Current Password is - {{ $password }}</p>
<p><a href="{{ url('wholesale/password/change', $uniqueCode) }}" target="_blank">Click Here</a> to change your password</p>